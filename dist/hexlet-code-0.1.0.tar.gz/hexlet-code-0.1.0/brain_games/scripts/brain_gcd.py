from brain_games.games import brain_gcd
from brain_games.core import game


def main():
    game(brain_gcd)


if __name__ == '__main__':
    main()
